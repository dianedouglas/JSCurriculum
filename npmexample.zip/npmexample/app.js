var bcrypt = require('bcrypt');
var unsecurePlainTextPassword = "password";
bcrypt.genSalt(10, function(err, salt){
  bcrypt.hash(unsecurePlainTextPassword, salt, function(err, hash){
    console.dir(hash);
  });
})
