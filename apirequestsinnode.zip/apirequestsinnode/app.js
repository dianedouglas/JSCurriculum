console.log("Hello world");
// var http = require("http");
//your .js files are modules and just like the core node modules you can require them like http.
var profile = require("./profile.js");
//.js optional, path is mandatory.
//then you can call functions from that file.


//var username = "dianedouglas";
//but you do need to specify which functions in your module are allowed to be used when the module is required.
//you do that with:
//module.exports.giveItAName = publicFunctionName;
//profile.get(username);

//multiple users.
// var users = ["chalkers", "dianedouglas"];
// users.forEach(function(username){
//   profile.get(username);
// });
//methods like forEach are safe in node because node uses Chrome's open source V8 JavaScript engine.

//use global object 'process' to get info about node and arguments from command line.
//console.dir(process.argv)
//gives you all the info about node including version and arguments
//use slice on the process.argv array to get desired args. you want 2 because arguments 0 and 1 are 'node' and the path to the root file you're running (app.js)
var users = process.argv.slice(2); //cut off the arguments < 2 and return rest of array.
users.forEach(function(username){
  profile.get(username);
});

//exercises
//friendly errors
//extract into modules
//take a zip code and query a weather api to get the weather at the current time in that area.

var location = require("./location.js");
