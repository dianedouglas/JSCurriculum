var http = require("http");

//needs free account and api key on openweathermap.org
//under 'setup' tab you'll see a form field labelled "API Key"
//example: e572e1a4c7b5d74308c11f537d1682e0
//API Call format: http://api.openweathermap.org/data/2.5/forecast/city?id=524901&APPID={APIKEY}
//with example id: http://api.openweathermap.org/data/2.5/weather?q=Portland&APPID=e572e1a4c7b5d74308c11f537d1682e0

var apiKey = "e572e1a4c7b5d74308c11f537d1682e0";
var city = "Portland";

var request = http.get('http://api.openweathermap.org/data/2.5/weather?q=' + city + '&APPID=' + apiKey, function(response){
  // check to make sure no errors
  // console.dir(response);

  var body = "";
  response.on('data', function(chunk){
    body += chunk;
  });

  response.on('end', function(){
    //when transmission is finished, process it.
    var weatherStuff = JSON.parse(body);
    // console.dir(weatherStuff);
    //if you see square brackets, use forEach to go through array.
    weatherStuff.weather.forEach(function(weatherConditions){
      console.log(weatherConditions.main);
      console.log(weatherConditions.description);
    });
    console.log("Currently, the temperature is: " + weatherStuff.main.temp);
    console.log("The pressure is: " + weatherStuff.main.pressure);
    console.log("Currently, the temperature is: " + weatherStuff.main.humidity);
  });
  //exercises with print messages based on the forcast (windspeed etc)
  //start with getting the ip address, then weather because more data to parse.
});


/*

Steps for this kind of problem:
1. Make a basic request to the correct URL and print the response in the terminal with console.dir.
2. Add logic to collect the chunks of data and parse them when transmission is complete
3. Process your data and display the results of the API call
4. Add error handling:

  - check status code with
  //inside of the request, inside of the 'end' event's function

  response.on('end', function() {
    if (response.statusCode === 200) {
      //do stuff
    } else { console.error("Error: " + http.STATUS_CODES[response.statusCode]); }
  )};

  - check connection error
  //after the request object is created.

  var request = http.get("http://url.com", function(response){});
  request.on('error', function(){
    console.error("Connection error!");
  });

  - try/catch parsing error
  //inside of the request, inside of the 'end' event's function, inside of status code check

  if (response.statusCode === 200) { //only if status is good, try to parse json
    try {

    } catch (error) {
      console.error("There was an error parsing your data.");
    }
  }




*/
