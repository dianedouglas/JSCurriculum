var https = require("https");

function printMessage(username, badgeCount, points) {
  var message = username + " has " + badgeCount + " total badge(s) and " + points + " points in JavaScript";
  console.log(message);
}

// request.on('error', function(error){
//   console.error(error.message);
// });

function printError(error){
  console.error(error.message);
}


function get(username){
  var request = https.get("https://teamtreehouse.com/" + username + ".json", function(response){
    console.dir(response.statusCode);
    //on a data event, when data is received in the response it comes in as a chunk.
    var body = "";
    response.on('data', function(chunk) {
      body += chunk;
    });

    //whether we're getting data from a file or an api over a network, there's always a data event where you can get 'chunks'
    //and there's also an end event for when all data is received.
    response.on('end', function() {
      // console.log(body);
      //don't forget you can use typeof to see what kind of object you have
      // console.log(typeof body);
      if (response.statusCode === 200) {
        try { //parsing error
          var profile = JSON.parse(body);
          printMessage(username, profile.badges.length, profile.points.JavaScript);
        } catch (error) {
          printError(error);
        }
      } else {
        //check status code
        printError({message: "There was an error getting the thing. " + http.STATUS_CODES[response.statusCode]});
      }
    });
  });


  //connection error handling
  request.on('error', printError);
}


module.exports.get = get;
