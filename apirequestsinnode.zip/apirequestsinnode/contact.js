//fullcontact.com api requires an account, free, enter phone and get text with pin to verify.
//parse data to get full name from email using api.
//just copy the full command  and
var https = require("https");
// var request = https.get('https://api.fullcontact.com/v2/person.json?email=antifreeze33@hotmail.com&apiKey=c2722f506b120caf', function(response){
//   var body = "";
//   response.on('data', function(chunk){
//     body += chunk;
//   });
//   response.on('end', function(){
//     var data = JSON.parse(body);
//     console.dir(data);
//     // console.log("that person's full name is probably " + data.contactInfo.fullName);
//   });
// });
var domain = process.argv.slice(2);
var request = https.get('https://api.fullcontact.com/v2/company/lookup.json?domain=' + domain + '&apiKey=c2722f506b120caf', function(response){
  var body = "";
  response.on('data', function(chunk){
    body += chunk;
  });
  response.on('end', function(){
    var data = JSON.parse(body);
    console.dir(data);
    // console.log("that person's full name is probably " + data.contactInfo.fullName);
  });
});
