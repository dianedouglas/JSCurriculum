var http = require("http");

var request = http.get('http://jsonip.com', function(response) {

  //get the chunks of data and store them as a string.
  var body = "";
  response.on('data', function(chunk) {
    body += chunk;
  });

  //when response signals that it has ended, parse the data.
  response.on('end', function() {
    var data = JSON.parse(body);
    console.dir(data.ip);
  });


});
